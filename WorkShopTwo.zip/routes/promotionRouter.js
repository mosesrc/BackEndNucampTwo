const express = require('express');
const Promotion = require('../models/promotion');

const promotionRouter = express.Router();

promotionRouter
  .route('/')
  .get((req, res, next) => {
    Promotion.find()
      .then((promotions) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json'); // we are going to sen back plain text in the response body
        res.json(promotions);
      })
      .catch((err) => next(err));
  })
  .post((req, res, next) => {
    Promotion.create(req.body)
      .then((promotion) => {
        console.log('Promotion Created', promotion);
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json'); // we are going to sen back plain text in the response body
        res.json(promotion);
      })
      .catch((err) => next(err));
  })
  .put((req, res) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /promotions');
  })
  .delete((req, res, next) => {
    Promotion.deleteMany()
      .then((response) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json'); // we are going to sen back plain text in the response body
        res.json(response);
      })
      .catch((err) => next(err));
  });

promotionRouter
  .route('/:promotionId')
  .get((req, res, next) => {
    Promotion.findById(req.params.promotionId)
      .then((promotion) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json'); // we are going to sen back plain text in the response body
        res.json(promotion);
      })
      .catch((err) => next(err));
  })
  .post((req, res, next) => {
    res.statusCode = 403;
    res.end(
      `POST operation not supported on /promotions/${req.params.promotionId}`
    );
  })
  .put((req, res, next) => {
    Promotion.findById(req.params.promotionId)
      .then((promotion) => {
        if (promotion) {
          if (req.body.name) {
            promotion.name = req.body.name;
          }
          if (req.body.cost) {
            promotion.cost = req.body.cost;
          }
          if (req.body.description) {
            promotion.description = req.body.description;
          }
          promotion.save().then((partner) => {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json'); // we are going to sen back plain text in the response body
            res.json(promotion);
          });
        } else if (!promotion) {
          err = new Error(` Partner {$req.params.promotionId} not found`);
          err.status = 404;
          return next(err); //passes off error to the express error handling system
        }
      })
      .catch((err) => next(err));
  })
  .delete((req, res, next) => {
    Promotion.findByIdAndDelete(req.params.promotionId)
      .then((response) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json'); // we are going to sen back plain text in the response body
        res.json(response);
      })
      .catch((err) => next(err));
  });

module.exports = promotionRouter;
